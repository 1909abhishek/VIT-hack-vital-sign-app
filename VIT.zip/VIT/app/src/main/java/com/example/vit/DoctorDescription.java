package com.example.vit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DoctorDescription extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_description);
    }
}